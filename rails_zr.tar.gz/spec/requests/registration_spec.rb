require 'rails_helper'

RSpec.describe "Registrations", type: :request do
  describe 'register checking' do
    before do
      Rails.application.load_seed
    end
    context 'paths for not auth user' do
      scenario 'success while registration' do
        visit new_account_registration_path
        fill_in :account_username, with: 'tst'
        fill_in :account_first_name, with: 'tst'
        fill_in :account_last_name, with: 'tst'
        fill_in :account_email, with: '123123@mail.com'
        fill_in :account_password, with: '123123'
        fill_in :account_password_confirmation, with: '123123'
        
        find('.actions .btn-sign_up').click
        expect(page).not_to be_nil 
      end
    end

    context 'paths for auth user' do
      scenario 'success while loging in' do
        visit new_account_session_path
        fill_in :account_email, with: 'qwerty12@gmail.com'
        fill_in :account_password, with: 'qwerty12'

        find('.form-group .btn-log_in').click
        expect(page).not_to be_nil 
      end
    end
  end
end
