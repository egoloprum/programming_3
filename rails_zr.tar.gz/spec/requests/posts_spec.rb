require 'rails_helper'

RSpec.describe "Posts", type: :request do
  describe 'New post' do
    before do
      Rails.application.load_seed

      visit new_account_session_path
      fill_in :account_email, with: 'qwerty12@gmail.com'
      fill_in :account_password, with: 'qwerty12'
      find('.btn-log_in').click
      sleep(0.1)
    end

    scenario 'creating' do
      count_before = Post.all.count
      visit new_post_path
      image_path = '/Users/Omen/rails_zr/app/assets/images/image.jpg'
      # attach_file("current_account[image]", image_path)
      # click_button 'Save Post'
      expect(Post.all.count - count_before).not_to be_nil
    end
  end
end
