require 'rails_helper'

RSpec.describe "Accounts", type: :request do
  describe "posts" do
    before do
      Rails.application.load_seed

      visit new_account_session_path
      fill_in :account_email, with: 'qwerty12@gmail.com'
      fill_in :account_password, with: 'qwerty12'
      find('.btn-log_in').click
      sleep(0.1)
    end


    it 'counts' do
      # visit profile_path(current_account.username)
      expect(Post.all.count).to eq(0)
    end
  end
end
