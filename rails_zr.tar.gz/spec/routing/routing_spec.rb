require 'rails_helper'

RSpec.describe PostsController, type: :routing do
    describe "routing" do
      it "routes to new_account_session" do
        expect(get: "/accounts/sign_in").to route_to("devise/sessions#new")
      end
      it "routes to account_session" do
        expect(post: "/accounts/sign_in").to route_to("devise/sessions#create")
      end
      it "routes to destroy_account_session" do
        expect(delete: "/accounts/sign_out").to route_to("devise/sessions#destroy")
      end

      it "routes to dashboard" do
        expect(get: "/dashboard").to route_to("accounts#index")
      end
      it "routes to follow_account" do
        expect(post: "/follow/account").to route_to("accounts#follow_account")
      end

      it "routes to public_about_me" do
        expect(get: "/public/about_me").to route_to("public#about_me")
      end

      it "routes to posts" do
        expect(post: "/posts").to route_to("posts#create")
      end
      it "routes to new_post" do
        expect(get: "/posts/new").to route_to("posts#new")
      end
      it "routes to root" do
        expect(get: "/").to route_to("public#homepage")
      end
    end
end