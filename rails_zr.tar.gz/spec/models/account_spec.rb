require 'rails_helper'

RSpec.describe Account, type: :model do
  describe 'return success' do
    it 'creating account' do
      account = Account.new(username: 'Ergo', first_name: 'Tuk',
        last_name: 'Jap', email: 'qwerty16@gmail.com',
        password: 'qwerty12', password_confirmation: 'qwerty12')
      account.valid?
      account.save
      expect(account).not_to be_nil
    end
  end

  describe 'should expect error if' do
    context 'email' do
      it 'is nil' do
        account = Account.new(username: 'Ergo', first_name: 'Tuk',
          last_name: 'Jap',
          password: 'qwerty12', password_confirmation: 'qwerty12')
        account.valid?
        error = account.errors.first
        expect(error.attribute).to eq(:email)
        expect(error.type).to eq(:blank)
      end
    end

    it 'password is nil' do
      account = Account.new(username: 'Ergo', first_name: 'Tuk',
        last_name: 'Jap', email: 'qwerty16@gmail.com', password_confirmation: 'qwerty12')
      account.valid?
      error = account.errors.first
      expect(error.type).to eq(:blank)
    end
  end
end
