require 'rails_helper'

RSpec.describe Post, type: :model do
  before do
    Rails.application.load_seed
  end

  describe 'return success' do
    it 'while creating post' do
      post = Post.new
      post.image.attach(io: File.open("#{Rails.root}/app/assets/images/image.jpg"), filename: 'image.jpg', content_type: 'image/jpg')
      post.valid?
      post.save
      expect(post).not_to be_nil
    end
  end

  describe 'should expect error if' do
    it 'account_id is nil' do
      post = Post.new
      post.valid?
      error = post.errors.first
      expect(error.attribute).to eq(:account)
      expect(error.type).to eq(:blank)
    end
    
    it 'post is nil' do
      post = Post.new(account_id: 3)
      post.valid?
      error = post.errors.first
      expect(error.attribute).to eq(:account)
      expect(error.type).to eq(:blank)
    end
  end
end
