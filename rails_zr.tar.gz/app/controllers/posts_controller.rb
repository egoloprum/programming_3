class PostsController < ApplicationController
    before_action :authenticate_account!
    
    def new
        @post = Post.new 
    end

    def create
        @post = Post.new(post_params)
        @post.account_id = current_account.id if account_signed_in?

        if params.require(:post).permit(:image).blank?
            redirect_to new_post_path, flash: { danger: "Post was not created" }
        else @post.update(post_params)
            redirect_to dashboard_path, flash: { success: "Post was created" }
        end
    end

    def show
    end

    def destroy
        @post = Post.find(params[:id])
        @post.destroy
        redirect_to dashboard_path
    end

    private

    def post_params
        params.require(:post).permit(:image, :description)
    end

end