Rails.application.routes.draw do

  scope "(:locale)", locale: /#{I18n.available_locales.join("|")}/ do
    devise_for :accounts 
    get "/dashboard" => "accounts#index"
    get "/profile/:username" => "accounts#profile", as: :profile
    post "follow/account" => "accounts#follow_account", as: :follow_account
    get 'public/about_me'
    
    resources :posts, only: [:new, :create, :show]

    root to: "public#homepage"
    get "account/dashboard"

    delete '/posts/:id' => 'posts#destroy'
  end
  
end